from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SubmitField
from wtforms.validators import InputRequired, Length

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=3, max=150)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=3, max=150)])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=3, max=150)])
    password = PasswordField('Password', validators=[InputRequired()])
    submit = SubmitField('Login')

class GameForm(FlaskForm):
    title = StringField('Название игры', validators=[InputRequired()])
    genre = StringField('Жанр', validators=[InputRequired()])
    play_time = StringField('Время игры', validators=[InputRequired()])
    description = TextAreaField('Описание', validators=[InputRequired()])
    components = TextAreaField('Компоненты', validators=[InputRequired()])
    rules = TextAreaField('Правила', validators=[InputRequired()])
    submit = SubmitField('Добавить игру')
