from flask import Flask, render_template, redirect, url_for, request, send_file
from models import db, User, Game
from forms import RegisterForm, LoginForm, GameForm
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import io
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'

db.init_app(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# -------------------------------
# Главная страница
# -------------------------------
@app.route('/')
def index():
    games = Game.query.order_by(Game.id.desc()).all()
    return render_template('index.html', games=games)

# -------------------------------
# Регистрация
# -------------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed = generate_password_hash(form.password.data)
        user = User(username=form.username.data, password=hashed)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

# -------------------------------
# Вход
# -------------------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            return redirect(url_for('index'))
    return render_template('login.html', form=form)

# -------------------------------
# Выход
# -------------------------------
@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

# -------------------------------
# Добавление игры
# -------------------------------
@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_game():
    form = GameForm()
    if form.validate_on_submit():
        game = Game(
            title=form.title.data,
            genre=form.genre.data,
            play_time=form.play_time.data,
            description=form.description.data,
            components=form.components.data,
            rules=form.rules.data,
            author=current_user
        )
        db.session.add(game)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_game.html', form=form)

# -------------------------------
# Редактирование игры
# -------------------------------
@app.route('/edit/<int:game_id>', methods=['GET', 'POST'])
@login_required
def edit_game(game_id):
    game = Game.query.get_or_404(game_id)
    if game.author != current_user:
        return "Вы не можете редактировать чужую игру", 403
    form = GameForm(obj=game)
    if form.validate_on_submit():
        game.title = form.title.data
        game.genre = form.genre.data
        game.play_time = form.play_time.data
        game.description = form.description.data
        game.components = form.components.data
        game.rules = form.rules.data
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_game.html', form=form, edit=True)

# -------------------------------
# Удаление игры
# -------------------------------
@app.route('/delete/<int:game_id>', methods=['POST'])
@login_required
def delete_game(game_id):
    game = Game.query.get_or_404(game_id)
    if game.author != current_user:
        return "Вы не можете удалить чужую игру", 403
    db.session.delete(game)
    db.session.commit()
    return redirect(url_for('index'))

# -------------------------------
# Просмотр отдельной игры
# -------------------------------
@app.route('/game/<int:game_id>')
def game(game_id):
    game = Game.query.get_or_404(game_id)
    return render_template('game.html', game=game)

# -------------------------------
# Экспорт PDF
# -------------------------------
@app.route('/export_pdf')
@login_required
def export_pdf():
    games = Game.query.filter_by(user_id=current_user.id).all()
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50

    # Абсолютный путь к шрифту DejaVuSans
    font_path = os.path.join(os.path.dirname(__file__), 'static', 'fonts', 'DejaVuSans.ttf')
    pdfmetrics.registerFont(TTFont('DejaVu', font_path))

    c.setFont("DejaVu", 20)
    c.drawString(50, y, f"Коллекция игр пользователя {current_user.username}")
    y -= 40

    c.setFont("DejaVu", 12)
    for game in games:
        if y < 100:
            c.showPage()
            y = height - 50
            c.setFont("DejaVu", 12)
        c.setFont("DejaVu", 14)
        c.drawString(50, y, game.title)
        y -= 20
        c.setFont("DejaVu", 12)
        c.drawString(60, y, f"Жанр: {game.genre}")
        y -= 15
        c.drawString(60, y, f"Время игры: {game.play_time}")
        y -= 15
        c.drawString(60, y, f"Описание: {game.description}")
        y -= 15
        c.drawString(60, y, f"Компоненты: {game.components}")
        y -= 15
        c.drawString(60, y, f"Правила: {game.rules}")
        y -= 30

    c.save()
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"{current_user.username}_games.pdf",
        mimetype='application/pdf'
    )

if __name__ == '__main__':
    app.run(debug=True)
