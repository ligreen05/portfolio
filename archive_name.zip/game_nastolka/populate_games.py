from app import app
from models import db, Game, User
from werkzeug.security import generate_password_hash

with app.app_context():
    user = User.query.first()
    if not user:
        user = User(username='admin', password=generate_password_hash('123'))
        db.session.add(user)
        db.session.commit()

    g1 = Game(
        title="Каркассон",
        genre="Стратегическая, семейная",
        play_time="30-45 минут",
        description="Постройте средневековый ландшафт, выкладывая тайлы и размещая своих миплов.",
        components="Тайлы, миплы, правила",
        rules="Выкладывайте тайлы на стол, ставьте миплов для захвата территорий. Считайте очки по завершению раунда.",
        author=user
    )

    g2 = Game(
        title="Колонизаторы",
        genre="Стратегическая",
        play_time="60-90 минут",
        description="Развивайте колонии, стройте дороги, города и собирайте ресурсы.",
        components="Карты, фишки, кубики",
        rules="Собирайте ресурсы и стройте поселения. Игрок с наибольшим количеством очков побеждает.",
        author=user
    )

    g3 = Game(
        title="Диксит",
        genre="Семейная, креативная",
        play_time="30 минут",
        description="Придумывайте подсказки к картинкам, чтобы другие угадывали вашу карту.",
        components="Карты с изображениями, жетоны голосования",
        rules="Игроки дают подсказку к своей карте. Остальные выбирают карту, которая подходит к подсказке. Считайте очки за угадывания.",
        author=user
    )

    db.session.add_all([g1, g2, g3])
    db.session.commit()
